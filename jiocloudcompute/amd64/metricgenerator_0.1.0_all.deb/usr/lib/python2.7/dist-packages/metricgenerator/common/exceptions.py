class IncorrectConfigException(Exception):
    pass

class LoggingException(Exception):
    pass

