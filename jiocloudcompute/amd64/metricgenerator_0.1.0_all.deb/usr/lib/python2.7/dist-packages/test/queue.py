from multiprocessing import Queue

queue = Queue(-1)
