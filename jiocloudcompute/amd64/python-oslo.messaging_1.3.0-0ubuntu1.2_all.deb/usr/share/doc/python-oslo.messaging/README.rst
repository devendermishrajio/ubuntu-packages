Oslo Messaging Library
======================

The Oslo messaging API supports RPC and notifications over a number of
different messaging transports.

* License: Apache License, Version 2.0
* Documentation: http://docs.openstack.org/developer/oslo.messaging
* Source: http://git.openstack.org/cgit/openstack/oslo.messaging
* Bugs: http://bugs.launchpad.net/oslo.messaging
